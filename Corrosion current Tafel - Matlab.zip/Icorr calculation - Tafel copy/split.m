function [ xa,ya ] = split( x,y,ip )

for i=1:length(ip)

    for t=1:ip(i)
        xa=x(t);
        ya=y(t);

    end

    for t=ip(i):ip(i+1)
        xa(t)=x(t);
        ya(t)=y(t);
    end

    for t=ip(i+1):ip(i+2)
        xa(t)=x(t);
        ya(t)=y(t);
    end
end

