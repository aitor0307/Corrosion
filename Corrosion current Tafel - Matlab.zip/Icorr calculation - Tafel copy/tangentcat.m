function [ tan,x,fprima,tcattaf ] = tangentcat( x,current,eq,val,index )


fprima=differentiate(eq,val);  % Calculate derivative

% Tangent to check Tafel behaviour
tcattaf=fprima*((x-x(index)))+(current(index)); % Calculate tangent points

% Tangent points for final plot
ext=max(x):0.01:(max(x)+10);  % Create values to extend x values so that the tangent intersects with tangentanode
x=[x ext]; % Extend the x values
tan=fprima*((x-x(index)))+(current(index)); % Calculate tangent points



end


