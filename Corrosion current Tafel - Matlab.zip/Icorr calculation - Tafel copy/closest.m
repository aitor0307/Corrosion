function [idx, val] = closest(testArr,val)

tmp = abs(testArr - val); %%% Create an array of difference values (All array new = all array - value)

[~, idx] = min(tmp); % Find the index of the minimum value in the new array

val = testArr(idx); % Get the value on the original array

% Code by Matt Gadaica, https://gist.github.com/mattgaidica/6da9f91fe5d673152d49133ce97ee9ff

end