function [Ep,r] = values( Table ,x,A)


Epp=Table(:,3)*1000;


Ipp=abs(Table(:,4))/A;      % Convert I to I/cm^2
a=min(Ipp(Ipp~=0));         % find value close to 0
r=find(Ipp==a);             %% Row for Ecorr


Ep=[Epp Ipp];

b=find(Ep(:,2),1,'first'); %Find the first element of the I value non zero
Ep(1:b+x,1:2)=0; %% Delete the first bad elements


end

