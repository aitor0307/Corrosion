%% Tafel by optimization around the specified value


function [x_icorr,y_icorr,error_ecorr,Ba,Bc]=tafel_opt(AnV,CatV,Ecorr,name,tafvalue,delta,tolerance)

len=length(CatV(:,1));
goodness=delta/len;
[catin, ~] = closest(abs(CatV(:,1)),Ecorr+delta); %% Take only these values
[anvin, ~] = closest(abs(AnV(:,1)),Ecorr-delta);


Ecat=abs(CatV(catin,1));  %%%% Value of potential selected in line 70-It's the first value...
                                ...in which there is data; so the furthermost to the left
                                    


E(1,1)=Ecat;
E(2,1)=Ecorr;

mmcat=CatV(catin:end,:);
mman=AnV(1:anvin,:);

%% Traslate X (V) values to 0V reference
 mmcat(:,1)=mmcat(:,1)+Ecat;
 mman(:,1)=mman(:,1)+Ecorr; 

%% When exponential 2 terms (original calculator)
ii=1;
if ii==0
%This figure compares the original (already split) vs. the traslated values to 0V

figure(1)
plot(mmcat(:,1)-Ecat,(mmcat(:,2)))
hold on
plot(mman(:,1)-Ecorr,(mman(:,2))) %,mman2(:,1)-Ecorr,(mman2(:,2)),mman3(:,1)-Ecorr,(mman3(:,2)),mman4(:,1)-Ecorr,(mman4(:,2)))
hold on
plot(mmcat(:,1),(mmcat(:,2)))
hold on
plot(mman(:,1)+(Ecat-Ecorr),(mman(:,2))) %,mman2(:,1)+(Ecat-Ecorr),(mman2(:,2)),mman3(:,1)+(Ecat-Ecorr),(mman3(:,2)),mman4(:,1)+(Ecat-Ecorr),(mman4(:,2)))
hold on
set(gca,'yscale','log','FontSize',16)
title(['Current vs potential ' name ])
ylabel('Current mA/cm^2')
xlabel('Potential vs Ag/AgCl')
grid on
hold on
end




%% Equation Cathode
% Curve fit for anode and cathode value
[NCatV,xcat,EqCat,catfiterror]=cathodefit(mmcat);
%[NCatV,xcat,EqCat,catfiterror]=cathodefit_exp1(mmcat);
xcatp=xcat-Ecat;
%xcatp=xcat; % Only for exp1
     
%% Equation Anode
%[NAnV,xan,EqAnV,anfiterror]=anodefit_exp1(mman,E);
[NAnV,xan,EqAnV,anfiterror]=anodefit(mman,E);
xanp=xan-(Ecat);


%% New plotting of fitted values vs. original values
if ii~=0
    %plotoriginalvsfitted(xcatp,EqCat,xanp,EqAnV,mmcat,mman,mman2,mman3,mman4,E,error)
    plotoriginalvsfitted_opt(xcatp,EqCat,xanp,EqAnV,mmcat,mman,E,name,goodness)
    dim = [0.15 0.08 0.15 0.3];
    str = {['Regression anode: ' num2str(anfiterror)], ['Regression cathode: ' num2str(catfiterror)]};
    an=annotation('textbox',dim,'String',str,'FitBoxToText','on');
    an.FontSize=16;
    hold on
end



%% Tangents and icorr optimization
    if exist('tafvalue','var')
        tafcat=tafvalue;
        tafan=tafvalue;
    else
        tafcat=30;
        tafan=30;
    end
error_ecorr=100;
i=1;
ilim=2000;
step=0.01;

while abs(error_ecorr)>0.02 && i<ilim % Flan
    
% Cathode tangent equation
    %%% Values taken at +-25mV of Ecorr both in the Cathode and Anode
    i=i+1;

    [idxc, valcat] = closest(xcat,max(xcat)-tafcat); %% Get value and position of Ecorr-25 in the xcat vector
    [tanicat,xcat2,fprimacat,ttcat]=tangentcat(xcat,EqCat,NCatV,valcat,idxc);

    xcattp=xcat2-Ecat; % Traslate tangent to its plotting position
% Anode tangent equation
    [idxa, valan] = closest(xan,(tafan+Ecat-Ecorr)); %% Get value and position of Ecorr+25 in the xan vector

    % Create function to check where this value is (NAnV, NAnV2, etc.)

    [tanian,xan2,Ba,ttan]=tangentan(xan,EqAnV,NAnV,valan,idxa);

    xantp=xan2-Ecat; % Traslate tangent to its plotting position
    [y_icorr,x_icorr]=icorrpoint(xcat2,xan2,tanicat,tanian,fprimacat,idxc,EqCat,Ecat); % Calculate intersection of both curves
    error_ecorr=((Ecorr)-abs(x_icorr));
        

        if error_ecorr<0
            tafan=tafan-step;
            tafcat=tafcat+step;
        elseif error_ecorr>0
            tafan=tafan+step;
            tafcat=tafcat-step;
            
%         else
         end
    Bc=fprimacat;
end

if i==ilim
    mess = sprintf('Convergence not achieved!');
    uiwait(warndlg(mess));
end

error_ecorr=abs(error_ecorr);
%% Plots

figure
hold on

% plot tangent curves
hcat=plot(xcattp,10.^(tanicat));
hold on
han=plot(xantp,10.^(tanian));
hold on
hcat.Color='k';
han.Color='k';
hcat.LineWidth=1;
han.LineWidth=1;

%Plot intersection point
plot(x_icorr,y_icorr,'r*','LineWidth',4)
hold on
% txt=['\leftarrow ' num2str(y_icorr) ' mA/cm^2'];
% t=text(x_icorr+0.05,y_icorr+0.0002,txt,'FontSize',18);

%plot fitted curves
plot(xcatp,10.^EqCat)
hold on
plot(xanp,10.^EqAnV)
hold on
y_icorr=y_icorr*1000; %% Change units to microAmperes from mA
%Plot details
plot(AnV(:,1),AnV(:,2),CatV(:,1),CatV(:,2))
set(gca,'YScale','log','FontSize',16)
line([-Ecorr -Ecorr],ylim,'LineWidth',1.5)
hold on
tit={['Current vs potential - ' name ];['Tafel position (mV): -' num2str(tafcat) ' +' num2str(tafan) ' vs. corrosion potential']};
title(tit)
ylabel('Current mA/cm^2')
xlabel('Potential vs Ag/AgCl')
xlim([-Ecat-30 (-Ecorr+50)])
ylim([1.0000e-05 1])
hold on
dim = [0.15 0.08 0.15 0.3];
str = {['Error vs. Ecorr: ' num2str(error_ecorr*1000) ' \muV'], ['Icorr: ' num2str(y_icorr) ' \muA/cm^2' ], ['Iterations: ' num2str(i)]};
a=annotation('textbox',dim,'String',str,'FitBoxToText','on');
a.FontSize=18;
grid on
 


%% Check Tafelian behaviour

tafelbehaviour(xanp,xcatp,10.^ttan,10.^ttcat,10.^EqAnV,10.^EqCat,tolerance,Ecorr,tit{2})
    


%% Plot original curves
% plot(mmcat(:,1),(mmcat(:,2)))
% hold on
% plot(mman(:,1)+(Ecat-Ecorr),(mman(:,2)),mman2(:,1)+(Ecat-Ecorr),(mman2(:,2)),mman3(:,1)+(Ecat-Ecorr),(mman3(:,2)),mman4(:,1)+(Ecat-Ecorr),(mman4(:,2)))
% hold on
% 
% set(gca,'YScale','log','FontSize',16)
% plot(xcat,10.^tanicat)
% hold on
% plot(xan,10.^tanian)
% hold on
% plot(xprima,y_icorr,'r*')
% hold on

end








