function plotoriginalvsfitted_opt(xcatp,EqCat,xanp,EqAnV,mmcat,mman,E ,name,goodness)

figure
hold on

plot(xcatp,10.^EqCat)
hold on
plot(xanp,10.^EqAnV)
hold on
plot(mmcat(:,1)-E(1,1),(mmcat(:,2)))
hold on
plot(mman(:,1)-E(2,1),(mman(:,2)))
hold on
grid on
line([-E(2,1) -E(2,1)],ylim)

%dim = [0.2 0.5 0.3 0.3];
%str = ['Errors: 1- ' num2str(error(1)) ' mA/cm^2, 2- '   num2str(error(2))  ' mA/cm^2, 3- ' num2str(error(3)) ' mA/cm^2'];
%a=annotation('textbox',dim,'String',str,'FitBoxToText','on');
%a.FontSize=18;

goodness=round(goodness*100,2);

set(gca,'yscale','log','FontSize',18)
title(['Fitted curves plotting ' name ', fitted : ' num2str(goodness) '%']) 
ylabel('Current mA/cm^2')
xlabel('Potential vs Ag/AgCl')
hold on





end

