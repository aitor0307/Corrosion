function [ as,bs,ea,eb] = smoothen( a,b )

as=a;
as(:,2)=smooth(a(:,2));



bs=b;
bs(:,2)=smooth(b(:,2));

ea=a(:,2)-as(:,2);  % Error of smoothing
eb=b(:,2)-bs(:,2);  % Error of smoothing

%%% Clean first elements of cathode
i=find(bs(:,1),1,'first'); %Find the last element of the I value non zero
bs(1:i+1,1:2)=0; %% Delete this first null element
eb(1:i+1)=0;




end

