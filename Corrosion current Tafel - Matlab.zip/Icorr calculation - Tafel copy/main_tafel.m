%% Icorr and tafel lines calculator

% This program here aims to help electrochemistry researchers with the determination of the corrosion current.
% There is no actual ruled procedure, so my approach is the following one:
%     - Clean up the noisy data acquired with a smoothing filter
%     - Remove the extreme parts far from the corrosion potential and keep only the values inside the region "delta" of study
%     - Get a double exponential equation that approaches the actual data log
%     - Get the tangent equations in the value "tafvalue" for each of the anodic and cathodic branches
%     - Get the intersection of the two tangents, so that a value of Potential & Current is obtained.
%     - The potential value is compared to the corrosion potential and the difference is spotted.
%     - If the difference is bigger than 2mV, run a loop to change the value on which the tangents are calculated.
%     - The final value is returned to the user and recorded if interested into an excel.
%     - Logaritmich plots are created to compare the difference between the real data and the tangent data, so that the user can compare the range of linearity
% 
%     Author: Aitor Gastaminza, September 2018, Melbourne, Australia
%     Contributors:
%         Rainier Catubig, Deakin University
%         Anthony Sommers, Deakin University
%         IFM, Melbourne, Australia
%         
% Please, feel free to make contributions to the project, enjoy and hope it helps!
    
    
function [data]=main_tafel
%% Data for analysis (user iput)
z=0; % Elements to delete
A=1; % Electrode area in cm^2
delta=60; % mV from Ecorr to values that will be fit 
%tafvalue=(input('Insert the starting range for tafel: '));
tafvalue=25;
tafeltolerance=0.6; % microA/cm2, Tolerance should be related to delta and tafvalue; the smaller the values the smaller the tolerance, hence, 
                     % bigger delta and bigger tafvalue, tolerance higher?
 
check=false;
while check==false
    [check,delta,tafvalue]=checktafelrange(delta,tafvalue,check);
end
    

%% Search for files
tic
myFolder = uigetdir('~/Tafel testing');
%myFolder = '/Users/OSX/Documents/Deakin University/Artificial Seawater 80HLES/Cet samples Cpp txt';
% Check to make sure that folder actually exists.  Warn user if it doesn't.
if ~isdir(myFolder)
  errorMessage = sprintf('Error: The following folder does not exist:\n%s', myFolder);
  uiwait(warndlg(errorMessage));
  return;
end
% Get a list of all files in the folder with the desired file name pattern.
filePattern = fullfile(myFolder, '*.txt'); % Change to whatever pattern you need.

theFiles = dir(filePattern);

%% Extract text properties; name, date, etc.

Cpname=cell([1 length(theFiles)]); %Preallocation
V=cell([1 length(theFiles)]); %Preallocation

for i=1:length(theFiles)
    
    
    V(i)=textscan(theFiles(i).name,'%s');  %%% Beware, V changes to be a cell structure!
    try
        % It will read the filenames to create titles for the plots.
        s1=char(V{i}(3));
        s2=char(V{i}(4));
        s3=char(V{i}(5));
        Cpname{i}=char([s1, 32, s2, 32, s3]); %%% Using 32= ' ' ASCII number
    catch
        Cpname{i}=input('Input a name for the first plot: ');
        %Cpname{i}='Whaaaaaaaat did you say?';
    end
end

%% Read files
[L,names]=readfilesCPP(theFiles, myFolder,V);

Values=cell([1 length(L)]); %Preallocation
AnV=cell([1 length(L)]);    %Preallocation
CatV=cell([1 length(L)]);   %Preallocation
AnVs=cell([1 length(L)]);   %Preallocation
CatVs=cell([1 length(L)]);  %Preallocation

for i=1:length(L)
    
[Values{1,i},r(i)]=values(L{i},z,A);%% raw E and I values, in columns
[AnV{i},CatV{i}]=anodecathode(Values{i},r(i));      %% Separate anode and cathode values
[AnVs{i},CatVs{i},~,~]=smoothen(AnV{i},CatV{i});    %% Smooth AnV and CatV values, and get anode error of smoothing and cathode error ean{i},ecat{i}
Ecorr(i)=Values{i}(r(i),1);                         %   Ecorr position is 'r'
%overpotentialplot(AnVs{i},CatVs{i},abs(Ecorr(i)))
[xicorr(i),yicorr(i),icerror(i),Ba(i),Bc(i)]=tafel_opt(AnVs{i},CatVs{i},abs(Ecorr(i)),Cpname{i},tafvalue,delta,tafeltolerance);

B(i)=1000*abs(Ba(i))*abs(Bc(i))/((abs(Ba(i))+abs(Bc(i)))*2.303); %% Calculate B values for further processing with LPR data
end
toc

%% Table to export to excel
exp=0;
if exp==1
    try
    vars=string(split(names')); % Get names for columns

    for i =1:length(vars(:,1))
        varNames(i)=cellstr([char(vars(i,2)) '_' char(vars(i,1))]);
    end

    varNames=regexprep(varNames,'(\<[a-z])','${upper($1)}'); % Capitalize first letter
    varNames=strrep(varNames,'1,1','');
    varNames=strrep(varNames,'+','_');

    rowNames={'Ecorr (mV)' ,'Ecorr calculated (mV)' ,'icorr (\muA/cm2)' ,'Ba (V)', 'Bc (V)', 'Error (mV)','Baver (mV)'}; %Names for rows


    data=array2table([Ecorr; xicorr; yicorr;Ba;Bc;icerror;B],'VariableNames',varNames,'RowNames',rowNames);

    outfile=char(strcat('~/Output data.xlsx'));
    catch
        disp('Could not save excel');
end

end
