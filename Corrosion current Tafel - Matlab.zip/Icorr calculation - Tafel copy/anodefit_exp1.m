function [ Eq,x,y,err] = anodefit_exp1( originalvalues,E)

xData=originalvalues(:,1)+(E(1,1)-E(2,1));
yData=log10(originalvalues(:,2));

% ft = fittype( 'exp2' );
% opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
% opts.Display = 'Off';
% opts.Normalize = 'on';


        [Eq,EqS]=fit(xData,yData,'exp1'); %%% Fitting anode values
        err=EqS.rsquare;
        fprintf('Anode Rsquare value %s\n',EqS.rsquare)
        
        % Calculate i values for X range
        x=(originalvalues(1,1):0.01:max(originalvalues(:,1)))+(E(1,1)-E(2,1));
        %y=Eq.a*exp(Eq.b*x) + Eq.c*exp(Eq.d*x);
        y=-Eq.a*exp(Eq.b*x);
end

