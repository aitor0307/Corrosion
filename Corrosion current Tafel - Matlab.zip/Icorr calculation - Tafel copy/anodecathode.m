function [anode,catode]=anodecathode(Val,r)

anode=Val(r:length(Val),:);
catode=Val(1:r,:);


end