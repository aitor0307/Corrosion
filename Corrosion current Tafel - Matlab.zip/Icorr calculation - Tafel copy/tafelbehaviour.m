function tafelbehaviour(xan,xcat,yan,ycat,oan,ocat,tol,Ecorr,tit)

    plttype={'linear', 'log'};
    type=1; %Change to 2 for a log plot
    
    %With absolute values
    Dan=abs(-yan+oan);
    Dcat=abs(-ycat+ocat);
    
    %With real values
    %Dan=(-yan+oan);
    %Dcat=(-ycat+ocat);
    
    tol=tol/1000; %change the tolerance to miliamperes so as to be comparable
    
    % Find elements below tolerance
    cf=find(Dcat<=tol,1);
    cl=find(Dcat<=tol,1,'last');
    af=find(Dan<=tol,1);
    al=find(Dan<=tol,1,'last');
    [~,ctext]=min(Dcat);
    [~,atext]=min(Dan);
    
    % Fin tafelian behaviour length
    deltacat=abs(abs(xcat(cf))-abs(xcat(cl)));
    deltaan=abs(abs(xan(al))-abs(xan(af)));
    
    % Decade calculation.. not really sure about this
%     delicat=round(abs(ocat(cl))-abs(ocat(cf)),2); 
%     delian=round(abs(oan(af))-abs(oan(al)),2);
    
    
    % Plot figures
    figure
    
    ax1=subplot(2,1,1);
    ax2=subplot(2,1,2);
    % Cathode i (mA/cm2?dec)
    subplot(2,1,1)
    
    title({'Tafelian behaviour Cathode';[ string(tit)]})
    hold on
    
    area(xcat,Dcat,'FaceColor',[0 0.8 0],'FaceAlpha',0.5)
    set(ax1,'yscale',plttype{type})
    grid(ax1,'on')
    plot([xcat(cf) xcat(cl)],[tol tol],'-ro','LineWidth',3,'MarkerSize',5);
    line([-Ecorr -Ecorr],get(gca,'ylim'),'LineWidth',4);
    text(xcat(ctext)-25,tol,['Tafel behaviour for ' num2str(deltacat) ' mV with tolerance <' num2str(tol*1000) '\muA/cm^2' ],'FontSize',16);
    %text(xcat(ctext),tol+0.15,['Tafel behaviour: ' num2str(deltacat) ' mV in ' num2str(delicat) ' decades'],'FontSize',16);
    
    ylabel('Current difference (\muA/cm^2)')
    set(gca,'FontSize',16)
    xlabel('Potential vs Ag/AgCl')
    
    % Anode i (mA/cm2?dec)
    subplot(2,1,2)
    hold on
    title({'Tafelian behaviour Anode';[ string(tit)]})
    hold on
    
    area(xan,Dan,'FaceColor',[0 0.8 0],'FaceAlpha',0.5)
    hold on
    set(ax2,'yscale',plttype{type})
    grid(ax2,'on')
    plot([xan(af) xan(al)],[tol tol],'-ro','LineWidth',3,'MarkerSize',5);
    line([-Ecorr -Ecorr],get(gca,'ylim'),'LineWidth',4);
    text(xan(atext)-10,tol,['Tafel behaviour for ' num2str(deltaan) ' mV with tolerance <' num2str(tol*1000) '\muA/cm^2'],'FontSize',16);
    %text(xan(atext),tol+0.15,['Tafel behaviour: ' num2str(deltaan) ' mV in ' num2str(delian) ' decades'],'FontSize',16);
    
    ylabel('Current difference (\muA/cm^2)')
    set(gca,'FontSize',16)
    xlabel('Potential vs Ag/AgCl')
    
    
    
    
    
end