function [ yi,xi ] = icorrpoint(xcat,xan,tancat,tanan,fprimacat,idxc,current,Ecat )

[lc,vc] = closest(xcat,xan(1)); % Find the values in which the lines are coincident in the X axis 
[la,va] = closest(xan,xcat(end));

xintersect=lc:1:la;

[~,ndex]=min(abs(tancat(length(xcat(1:lc)):end)-tanan(1:length(xan(1:la))))); % Find index value in which both lines interesect


y_icorr=tancat(ndex+lc); % Obtain Y value for the tangent cat line
x_icorr=(y_icorr-(current(idxc)))/fprimacat+xcat(idxc); % Obtain X pair value for Y in the tangent cat line
xprima=x_icorr; % Save this value (referenced to 0V)
xi=x_icorr-Ecat; % Obtain real X value
yi=10.^y_icorr; % Change to log axes


%%% Check intersection in 0V reference

%figure(3)
%plot(xprima,y_icorr,'k*')
%hold on






end

