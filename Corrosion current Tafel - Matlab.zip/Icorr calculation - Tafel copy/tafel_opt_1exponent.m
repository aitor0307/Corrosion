%% Start program


function [x_icorr,y_icorr,error_ecorr,Ba,Bc]=tafel_opt_1exponent(AnV,CatV,Ecorr,name,tafvalue)


[catin, ~] = closest(abs(CatV(:,1)),Ecorr+35); %% Take only these values
[anvin, ~] = closest(abs(AnV(:,1)),Ecorr-35);


Ecat=abs(CatV(catin,1));  %%%% Value of potential selected in line 70-It's the first value...
                                ...in which there is data; so the furthermost to the left
                                    


E(1,1)=Ecat;
E(2,1)=Ecorr;

% mmcat=zeros(length(CatV)-endcutcat,2);
% mman=zeros(cutan,2);
% mman2=zeros(cutan2-cutan+1,2);
% mman3=zeros(cutan3-cutan2+1,2);

mmcat=CatV(catin:end,:);
mman=AnV(1:anvin,:);

% % for j=1:2  %%%%%% Cathode fitting equation values
% %     
% %     for i=1:(length(CatV)-catin)
% %         mmcat(i,j)=CatV(length(CatV)-catin,j);
% %     end
% % end
% 
% for j=1:2  %%%%%% Anode fitting equation values: cutting it in different parts to fit anode
%     
%     for i=1:cutan
%         mman(i,j)=AnV(i,j);
%     end
%     
%     for i=cutan:cutan2 
%         mman2(i+1-cutan,j)=AnV(i,j);
%     end
%     
%     for i=cutan2:cutan3
%         mman3(i+1-cutan2,j)=AnV(i,j);
%     end
%     for i=cutan3:(length(AnV)-endcutan)   
%         mman4(i+1-cutan3,j)=AnV(i,j);
%     end
% end

%% Traslate X (V) values to 0V reference
 mmcat(:,1)=mmcat(:,1)+Ecat;
 mman(:,1)=mman(:,1)+Ecorr; 





% mman2(:,1)=mman2(:,1)+Ecorr;
% mman3(:,1)=mman3(:,1)+Ecorr;
% mman4(:,1)=mman4(:,1)+Ecorr;

%% When exponential 2 terms (original calculator)
ii=0;
if ii==0
%This figure compares the original (already split) vs. the traslated values to 0V

figure(1)
plot(mmcat(:,1)-Ecat,(mmcat(:,2)))
hold on
plot(mman(:,1)-Ecorr,(mman(:,2))) %,mman2(:,1)-Ecorr,(mman2(:,2)),mman3(:,1)-Ecorr,(mman3(:,2)),mman4(:,1)-Ecorr,(mman4(:,2)))
hold on
plot(mmcat(:,1),(mmcat(:,2)))
hold on
plot(mman(:,1)+(Ecat-Ecorr),(mman(:,2))) %,mman2(:,1)+(Ecat-Ecorr),(mman2(:,2)),mman3(:,1)+(Ecat-Ecorr),(mman3(:,2)),mman4(:,1)+(Ecat-Ecorr),(mman4(:,2)))
hold on
set(gca,'yscale','log','FontSize',16)
title(['Current vs potential ' name])
ylabel('Current mA/cm^2')
xlabel('Potential vs Ag/AgCl')
grid on
hold on
end




%% Equation Cathode
% Curve fit for anode and cathode value
%[NCatV,xcat,EqCat,catfiterror]=cathodefit(mmcat);
[NCatV,xcat,EqCat,catfiterror]=cathodefit_exp1(mmcat);
xcatp=xcat-Ecat;
%xcatp=xcat; % Only for exp1
     
%% Equation Anode
[NAnV,xan,EqAnV,anfiterror]=anodefit_exp1(mman,E);
%[NAnV,xan,EqAnV,anfiterror]=anodefit(mman,E);
xanp=xan-(Ecat);







%         %%% 2nd equation anode
% [NAnV2,xan2,EqAnV2]=anodefit(mman2,E);
% 
%      
%         %%% 3rd equation anode
% [NAnV3,xan3,EqAnV3]=anodefit(mman3,E);          
% 
%       
%         %%% 4th equation anode
% [NAnV4,xan4,EqAnV4]=anodefit(mman4,E);        
%      
%         

% Collect all i and V values  
%    error(1,1)=abs(EqAnV(end)-EqAnV2(1));
%     error(2,1)=abs(EqAnV2(end)-EqAnV3(1));
%     error(3,1)=abs(EqAnV3(end)-EqAnV4(1));

% EqAnV=[EqAnV EqAnV2 EqAnV3 EqAnV4];
% xan=[xan xan2 xan3 xan4];

    

%% New plotting of fitted values vs. original values

    %plotoriginalvsfitted(xcatp,EqCat,xanp,EqAnV,mmcat,mman,mman2,mman3,mman4,E,error)
    plotoriginalvsfitted_opt_1exponent(xcatp,EqCat,xanp,EqAnV,mmcat,mman,E,name)
    dim = [0.15 0.08 0.15 0.3];
    str = {['Regression anode: ' num2str(anfiterror)], ['Regression cathode: ' num2str(catfiterror)]};
    an=annotation('textbox',dim,'String',str,'FitBoxToText','on');
    an.FontSize=16;
    hold on




%% Tangents and icorr optimization
    if exist('tafvalue','var')
        tafcat=tafvalue;
        tafan=tafvalue;
    else
    tafcat=30;
    tafan=30;
    end
error_ecorr=100;
i=1;
itnum=10000;

while abs(error_ecorr)>0.02 && i<itnum
% Cathode tangent equation
    %%% Values taken at +-25mV of Ecorr both in the Cathode and Anode
    i=i+1;

    [idxc, valcat] = closest(xcat,max(xcat)-tafcat); %% Get value and position of Ecorr-25 in the xcat vector
    [tanicat,xcat2,fprimacat]=tangentcat(xcat,EqCat,NCatV,valcat,idxc);

    xcattp=xcat2-Ecat; % Traslate tangent to its plotting position

% Anode tangent equation



        

    [idxa, valan] = closest(xan,(tafan+Ecat-Ecorr)); %% Get value and position of Ecorr+25 in the xan vector

    % Create function to check where this value is (NAnV, NAnV2, etc.)

    [tanian,xan2,Ba]=tangentan(xan,EqAnV,NAnV,valan,idxa);

    xantp=xan2-Ecat; % Traslate tangent to its plotting position


        [y_icorr,x_icorr]=icorrpoint(xcat2,xan2,tanicat,tanian,fprimacat,idxc,EqCat,Ecat); % Calculate intersection of both curves
        error_ecorr=((Ecorr)-abs(x_icorr));
        %a(i)=error_ecorr;

        if error_ecorr<0
            tafan=tafan-0.1;
            tafcat=tafcat+0.1;
        elseif error_ecorr>0
            tafan=tafan+0.1;
            tafcat=tafcat-0.1;
            
%         elseif i>=30
%             errorMessage = sprintf('Convergence not achieved!');
%             uiwait(warndlg(errorMessage));
         end
    Bc=fprimacat;
end

error_ecorr=abs(error_ecorr);
%% plot

figure
hold on

% plot tangent curves
hcat=plot(xcattp,10.^(tanicat));
hold on
han=plot(xantp,10.^(tanian));
hold on
hcat.Color='k';
han.Color='k';
hcat.LineWidth=1;
han.LineWidth=1;

%Plot intersection point
plot(x_icorr,y_icorr,'r*','LineWidth',4)
hold on
% txt=['\leftarrow ' num2str(y_icorr) ' mA/cm^2'];
% t=text(x_icorr+0.05,y_icorr+0.0002,txt,'FontSize',18);

%plot fitted curves
plot(xcatp,10.^EqCat)
hold on
plot(xanp,10.^EqAnV)
hold on
y_icorr=y_icorr*1000; %% Change units to microAmperes from mA
%Plot details
set(gca,'YScale','log','FontSize',16)
line([-Ecorr -Ecorr],ylim,'LineWidth',1.5)
hold on
title(['Current vs potential - ' name])
ylabel('Current mA/cm^2')
xlabel('Potential vs Ag/AgCl')
xlim([-Ecat-30 (-Ecorr+50)])
ylim([1.0000e-05 1])
hold on
dim = [0.15 0.08 0.15 0.3];
str = {['Error vs. Ecorr: ' num2str(error_ecorr*1000) ' \muV'], ['Icorr: ' num2str(y_icorr) ' \muA/cm^2' ], ['Iterations: ' num2str(i)]};
a=annotation('textbox',dim,'String',str,'FitBoxToText','on');
a.FontSize=18;
grid on
 
end

%Plot original curves
%plot(mmcat(:,1),(mmcat(:,2)))
%hold on
%plot(mman(:,1)+(Ecat-Ecorr),(mman(:,2)),mman2(:,1)+(Ecat-Ecorr),(mman2(:,2)),mman3(:,1)+(Ecat-Ecorr),(mman3(:,2)),mman4(:,1)+(Ecat-Ecorr),(mman4(:,2)))
%hold on

%set(gca,'YScale','log','FontSize',16)
%plot(xcat,10.^tanicat)
%hold on
%plot(xan,10.^tanian)
%hold on
%plot(xprima,y_icorr,'r*')
%hold on








