function [ Eq,x,y,err ] = cathodefit_exp1( originalvalues )

        [Eq,EqS]=fit(originalvalues(:,1),log10(originalvalues(:,2)),'exp1'); %%% Fitting Cathode values
        %R2catvalue=NCatS.rsquare; % In case the value is wanted it can be
        %returned
        err=EqS.rsquare;
        fprintf('Cathode Rsquare value %s\n',EqS.rsquare)
        
        % Calculate i values for X range
        x=originalvalues(1,1):0.01:max(originalvalues(:,1));
        %y=Eq.a*exp(Eq.b*x) + Eq.c*exp(Eq.d*x);
        y=Eq.a*exp(-Eq.b*x);

end

