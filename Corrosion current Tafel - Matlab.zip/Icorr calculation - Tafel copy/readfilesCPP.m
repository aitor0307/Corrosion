function [Val, izena] = readfilesCPP( add,fold,V)

for i = 1 : length(add)
  baseFileName = add(i).name;
  fullFileName = fullfile(fold, baseFileName);
  fprintf(1, 'Now reading %s\n', fullFileName);
  % Now do whatever you want with this file name,
  % such as reading it in as an image array with imread()
 % L(i).original = readtable(fullFileName);
 
  
      try
            Val{i}=readtable(fullFileName);
            Val{i}=table2array(Val{i});
      catch
            Val{i}=dlmread(fullFileName,'\t',1,0); 
      end
  
    try
        a=cell2mat(V{1,i}(5));
        b=cell2mat(V{1,i}(6)); %% 4 for test number, 6 for concentration
        c=cell2mat(V{1,i}(4));
        %   a=mat2char(a);
        %   b=mat2char(b);
        %   
        %gap=' ';
        izena(i)=string([c 32 a 32 b]);
    catch
        izena(i)=prompt('Input a name please:' );

    end

end

end

