function [ tan,x,fprima,tantaf ] = tangentan( x,current,eq,val,index )


fprima=differentiate(eq,val); % Calculate derivative

% Tangent to compare with fitted data and check Tafel behaviour
tantaf=fprima*((x-x(index)))+(current(index)); % Calculate tangent points

% Extended tangent
ext=min(x)-20:0.01:(min(x)); % Create values to extend x values so that the tangent intersects with tangentcat
index2=index+length(ext); % Index of x value has to be updated





x=[ext x]; % Extend the x values
tan=fprima*((x-x(index2)))+(current(index)); % Calculate tangent points



end
