function [c,d,nt]=checktafelrange(d,t,c)

if ~(t<d)
    tafMessage = sprintf('Error: Tafel tangents must be in a range in which curve fitting will be  done (tafel start range < delta (%g mV))',d);
    uiwait(warndlg(tafMessage));
    nt=(input('Insert the starting range for tafel: '));
else 
    c=true;
    nt=t;
end


end