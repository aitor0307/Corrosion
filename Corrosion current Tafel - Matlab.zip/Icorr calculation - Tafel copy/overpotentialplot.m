function overpotentialplot(an,cat,E)


delta=log10(cat(end,2))-log10(an(1,2));

figure
hold on
plot(an(:,1)+E,-log10(an(:,2))+delta)
plot(cat(:,1)+E,log10(cat(:,2))-delta)







end
