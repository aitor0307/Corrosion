%% Start program


function [x_icorr,y_icorr,error_ecorr]=tafel(V,r)
%load('C.mat') %% Cortar en linea 70
%load('A.mat') %% Cortar en linea 80
%%%% Load graphics in secondary monitor
%get(0,'MonitorPositions')
%load('screen_position.mat')
%set(0, 'DefaultFigurePosition', pos

[AnV,CatV]=anodecathode(V,r);
% AnV=Anode;
% CatV=Cathode;

%clear Anode;
%clear Cathode;

% cathode splitting, cut last "endcutcat" elements
endcutcat=30;

% anode splitting

cutan=35;
cutan2=50;
cutan3=75;
endcutan=80;  %% Cut the last "enductan" elements

%x = CatV(:,1);
%y = log10(CatV(:,2));

j0=min(CatV(:,2));
Ecorr=abs(AnV(1,1));
Ecat=abs(CatV(endcutcat+1,1));  %%%% Value of potential selected in line 70-It's the first value...
                                ...in which there is data; so the furthermost to the left
E(1,1)=Ecat;
E(2,1)=Ecorr;
mmcat=zeros(length(CatV)-endcutcat,2);
mman=zeros(cutan,2);
mman2=zeros(cutan2-cutan+1,2);
mman3=zeros(cutan3-cutan2+1,2);

for j=1:2  %%%%%% Cathode fitting equation values
    
    for i=1:length(CatV)-endcutcat  
        mmcat(i,j)=CatV(i+endcutcat,j);
    end
end

for j=1:2  %%%%%% Anode fitting equation values: cutting it in different parts to fit anode
    
    for i=1:cutan
        mman(i,j)=AnV(i,j);
    end
    
    for i=cutan:cutan2 
        mman2(i+1-cutan,j)=AnV(i,j);
    end
    
    for i=cutan2:cutan3
        mman3(i+1-cutan2,j)=AnV(i,j);
    end
    for i=cutan3:(length(AnV)-endcutan)   
        mman4(i+1-cutan3,j)=AnV(i,j);
    end
end

%Traslate X (V) values to 0V reference

mmcat(:,1)=mmcat(:,1)+Ecat;
mman(:,1)=mman(:,1)+Ecorr; 
mman2(:,1)=mman2(:,1)+Ecorr;
mman3(:,1)=mman3(:,1)+Ecorr;
mman4(:,1)=mman4(:,1)+Ecorr;

ii=1;
if ii==0
% This figure compares the original (already split) vs. the traslated values to 0V
% reference
figure(1)
plot(mmcat(:,1)-Ecat,(mmcat(:,2)))
hold on
plot(mman(:,1)-Ecorr,(mman(:,2)),mman2(:,1)-Ecorr,(mman2(:,2)),mman3(:,1)-Ecorr,(mman3(:,2)),mman4(:,1)-Ecorr,(mman4(:,2)))
hold on
plot(mmcat(:,1),(mmcat(:,2)))
hold on
plot(mman(:,1)+(Ecat-Ecorr),(mman(:,2)),mman2(:,1)+(Ecat-Ecorr),(mman2(:,2)),mman3(:,1)+(Ecat-Ecorr),(mman3(:,2)),mman4(:,1)+(Ecat-Ecorr),(mman4(:,2)))
hold on
set(gca,'yscale','log','FontSize',16)
title('Current vs potential')
grid on
hold on
end



%% Equation Cathode
% Curve fit for anode and cathode value
[NCatV,xcat,EqCat]=cathodefit(mmcat);
xcatp=xcat-Ecat;
     
%% Equation Anode

[NAnV,xan,EqAnV]=anodefit(mman,E);
          
        %%% 2nd equation anode
[NAnV2,xan2,EqAnV2]=anodefit(mman2,E);

     
        %%% 3rd equation anode
[NAnV3,xan3,EqAnV3]=anodefit(mman3,E);          

      
        %%% 4th equation anode
[NAnV4,xan4,EqAnV4]=anodefit(mman4,E);        
     
        

% Collect all i and V values  
   error(1,1)=abs(EqAnV(end)-EqAnV2(1));
    error(2,1)=abs(EqAnV2(end)-EqAnV3(1));
    error(3,1)=abs(EqAnV3(end)-EqAnV4(1));

EqAnV=[EqAnV EqAnV2 EqAnV3 EqAnV4];
xan=[xan xan2 xan3 xan4];
xanp=xan-(Ecat);
    

%% New plotting of fitted values vs. original values
if ii~=0
    plotoriginalvsfitted(xcatp,EqCat,xanp,EqAnV,mmcat,mman,mman2,mman3,mman4,E,error)
     

end



%% Tangents and icorr optimization
tafcat=25;
tafan=25;

% Cathode tangent equation
    %%% Values taken at +-25mV of Ecorr both in the Cathode and Anode
    

    [idxc, valcat] = closest(xcat,max(xcat)-tafcat); %% Get value and position of Ecorr-25 in the xcat vector
    [tanicat,xcat2,fprimacat]=tangentcat(xcat,EqCat,NCatV,valcat,idxc);

    xcattp=xcat2-Ecat; % Traslate tangent to its plotting position

% Anode tangent equation



        

    [idxa, valan] = closest(xan,(tafan+Ecat-Ecorr)); %% Get value and position of Ecorr+25 in the xan vector

    % Create function to check where this value is (NAnV, NAnV2, etc.)

    [tanian,xan2,fprimaan]=tangentan(xan,EqAnV,NAnV,valan,idxa);

    xantp=xan2-Ecat; % Traslate tangent to its plotting position

%% icorr

        [y_icorr,x_icorr]=icorrpoint(xcat2,xan2,tanicat,tanian,fprimacat,idxc,EqCat,Ecat); % Calculate intersection of both curves
        error_ecorr=abs(Ecorr)-abs(x_icorr);
       
%% plot

figure(3)
hold on

% plot tangent curves
hcat=plot(xcattp,10.^(tanicat));
hold on
han=plot(xantp,10.^(tanian));
hold on
hcat.Color='k';
han.Color='k';
hcat.LineWidth=1;
han.LineWidth=1;

%Plot intersection point
plot(x_icorr,y_icorr,'r*','LineWidth',4)
hold on
% txt=['\leftarrow ' num2str(y_icorr) ' mA/cm^2'];
% t=text(x_icorr+0.05,y_icorr+0.0002,txt,'FontSize',18);

%plot fitted curves
plot(xcatp,10.^EqCat)
hold on
plot(xanp,10.^EqAnV)
hold on

%Plot details
set(gca,'YScale','log','FontSize',16)
line([-Ecorr -Ecorr],ylim,'LineWidth',1.5)
hold on
title('Current vs potential')
xlim([-Ecat (-Ecorr+100)])
ylim([1.0000e-05 1])
hold on
dim = [0.17 0.5 0.15 0.3];
str = {['Error commited: ' num2str(error_ecorr) ' mV'], ['Icorr: ' num2str(y_icorr) ' mA/cm^2' ]};
a=annotation('textbox',dim,'String',str,'FitBoxToText','on');
a.FontSize=18;
grid on
end

%Plot original curves
%plot(mmcat(:,1),(mmcat(:,2)))
%hold on
%plot(mman(:,1)+(Ecat-Ecorr),(mman(:,2)),mman2(:,1)+(Ecat-Ecorr),(mman2(:,2)),mman3(:,1)+(Ecat-Ecorr),(mman3(:,2)),mman4(:,1)+(Ecat-Ecorr),(mman4(:,2)))
%hold on

%set(gca,'YScale','log','FontSize',16)
%plot(xcat,10.^tanicat)
%hold on
%plot(xan,10.^tanian)
%hold on
%plot(xprima,y_icorr,'r*')
%hold on








